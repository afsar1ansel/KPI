window.onload = function () {
  window.location.href = "./homePage.html";
};
